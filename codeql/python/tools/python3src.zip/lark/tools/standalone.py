# This file used to contain the Lark standalone tool.
#
# We do not use it, and it is licensed under the GPL, which is much
# more restrictive than the rest of Lark. In order to avoid depending
# on it accidentally, we exclude it from our repository and distribution.
# When LARK is upgraded, this file should be kept in preference to the
# original.
