email = "user@example.com"
dob = "2000-01-01"
print(email, dob) 