email = "user@example.com"
ssn = "123-45-6789"
db.insert(email, ssn)