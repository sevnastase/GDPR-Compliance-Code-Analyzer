email = "user@example.com"
print(email)