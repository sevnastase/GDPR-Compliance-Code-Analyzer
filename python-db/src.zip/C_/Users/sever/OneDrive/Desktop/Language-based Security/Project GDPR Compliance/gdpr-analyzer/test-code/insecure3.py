email = "user@example.com"
open("dump.txt", "w").write(email)