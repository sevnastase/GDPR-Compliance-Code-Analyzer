email = "user@example.com"

response.set_cookie(email)